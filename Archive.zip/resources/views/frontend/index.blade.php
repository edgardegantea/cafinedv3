<x-layouts.public.public>
    <div class="mb-5 relative">
        <div class="bg-white shadow-md overflow-hidden">
            <img class="w-full aspect-9/4 object-cover object-center" src="{{ Storage::disk('public')->url('images/frontend/1.png') }}"
                 alt="Image from Storage">
        </div>
    </div>





</x-layouts.public.public>
