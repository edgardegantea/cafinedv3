<div class="ms-1 grid flex-1 text-start text-sm">
    <span class="mb-0.5 truncate leading-none font-semibold">cafined lab</span>
</div>
<?php /**PATH /Users/edgardeganteaguilar/Herd/cafinedv3/resources/views/components/app-logo.blade.php ENDPATH**/ ?>