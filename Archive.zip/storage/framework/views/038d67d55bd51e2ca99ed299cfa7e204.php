
<div <?php echo e($attributes->class('flex')); ?> data-flux-breadcrumbs>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/edgardeganteaguilar/Herd/cafinedv3/vendor/livewire/flux/src/../stubs/resources/views/flux/breadcrumbs/index.blade.php ENDPATH**/ ?>