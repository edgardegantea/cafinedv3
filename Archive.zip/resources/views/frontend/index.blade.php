<x-layouts.public.public>
    <div class="container mx-auto py-8">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <img src="{{ Storage::disk('public')->url('images/frontend/1.png') }}"
                 alt="Image from Storage" class="w-full object-cover">
        </div>
    </div>



</x-layouts.public.public>
