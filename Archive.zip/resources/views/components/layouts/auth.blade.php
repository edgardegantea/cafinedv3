<x-layouts.auth.split :title="$title ?? null">
    {{ $slot }}
</x-layouts.auth.split>
