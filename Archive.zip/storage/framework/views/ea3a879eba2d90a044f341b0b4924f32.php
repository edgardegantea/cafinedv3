<?php echo e($slot); ?>

<?php /**PATH /Users/edgardeganteaguilar/Herd/cafinedv3/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>